/* Generator danych wejsciowych do zadania Prefiksy
   Autor: Karol Farbiś
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <numeric>
#include <cassert>
#include <set>
#include <queue>

#include "oi.h"

using namespace std;

// HINT: Uzywamy liczb losowych wylacznie z pakietu oi.h
oi::Random RG(0xfee1dead);

const int MAXN = 1000000;

double rand01() {
  return RG.rand() / (double) (1LL << 31);
}

int ra(int a, int b) {
  return a + (int) floor(rand01() * (b + 1 - a));
}

bool heads(double p){
	return rand01() < p;
}

template<class T>
struct Vector: vector<T> {
	Vector(): vector<T>() {}
	Vector(int __size): vector<T>(__size) {}

	Vector& operator << (const T& elem){
		this->push_back(elem);
		return *this;
	}

	Vector& shuffle(){
		RG.randomShuffle(this->begin(), this->end());
		return *this;
	}

	Vector& reverse(){
		::reverse(this->begin(), this->end());
		return *this;
	}

	Vector& sort(){
		::sort(this->begin(), this->end());
		return *this;
	}
};

template <class T>
struct Set: set<T> {
	Set& operator << (const T& elem){
		this->insert(elem);
		return * this;
	}
};

struct String: string {
	String& operator << (const char& elem){
		push_back(elem);
		return * this;
	}
};

struct renumerator : map<int, int> {
	renumerator(int n){
		Vector<int> x(n);
		iota(x.begin(), x.end(), 1);
		x.shuffle();

		int i = 1;
		Vector<int>::iterator it = x.begin();
		while(it != x.end()){
			map<int, int>::operator [](*(it++)) = i++;
		}
	}
};

class TestCase {
  public:
    friend ostream& operator << (ostream& out, const TestCase& testCase) {

        printf( "n = %d \t m = %d \t", (int)testCase.s1.size(), (int)testCase.s2.size() );
        string a1 = testCase.s1, a2 = testCase.s2;
		out << a1;
		out << endl;
		out << a2;
		out << endl;

      return out;
    }

	void make_exact(){
		s2=s1;
	}

  protected:
	void renumerate(){
		renumerator R(26);
		for(char& c : s1){ c = R[c-96]+96;}
		for(char& c : s2){ c = R[c-96]+96; }
	}

    TestCase() {}
	String s1, s2;
};

class RandomCase : public TestCase {
  public:
    RandomCase (int n, int m, int a) {
		assert(1<=n && n<=MAXN);
		assert(1<=m && m<=MAXN);
		assert(1<=a && a<=26);

		for(int i=1; i<=n; i++) s1 << ra('a', 'a'+a-1);
		for(int i=1; i<=m; i++) s2 << ra('a', 'a'+a-1);

		renumerate();
    }
};

class LowCase : public TestCase {
  public:
    LowCase (int n, int m, int a) {
		assert(1<=n && n<=MAXN);
		assert(1<=m && m<=MAXN);
		assert(1<=a && a<=26);

		for(int i=1; i<=n; i++) s1 << random(a);
		for(int i=1; i<=n/2; i++) s1[i] = 'a';
		for(int i=1; i<=m; i++) s2 << random(a);

		renumerate();
    }

	private:
	char random(int a){
		if(ra(1,1000) == 1) return ra(0, a-1) +'a';
		return 'a';
	}
};

class LongCase : public TestCase {
	public:
	LongCase (int n, int m, int a){
		assert(1<=n && n<=MAXN);
		assert(1<=m && m<=MAXN);
		assert(1<=a && a<=26);

		for(int i=1; i<=n; i++) s1 << ra('a', 'a'+a-1);
		int k = 0, t = 0;
		for(int i=1; i<=m; i++){
			if(k>=t){
				s2 << ra('a', 'a'+a-1);
				t = ra(0, n-1);
				k = 0;
			} else {
				s2 << s1[k++];
			}
		}

		renumerate();
	}
};

void write(const char* filename, const TestCase& testCase) {
  cout << "Writing " << filename << "..." << endl;
  ofstream file(filename);
  file << testCase;
  file.close();
}

void testGroup(const vector<TestCase>& cases) {
  static int test_no = 0;
  ++test_no;
  for (int i = 0; i < (int) cases.size(); ++i) {
    stringstream ss;
    ss << "suf";
    ss << test_no;
    if (cases.size() > 1U) {
      ss << char('a' + i);
    }
    ss << ".in";
    write(ss.str().c_str(), cases[i]);
  }
}

TestCase Exact(TestCase t, int next_seed=-1){
	t.make_exact();
	if( next_seed != -1 ) RG.setSeed(next_seed);
	return t;
}

int main() {

#define Begin(seed) { RG.setSeed(seed); { const TestCase t[] = {
#define End }; testGroup(vector<TestCase>(t, t+sizeof(t)/sizeof(TestCase)));} }
#define Next(seed) End Begin(seed)
	Begin(1) //1 [10]
		RandomCase(100, 100, 2),
		LowCase(97, 111, 26),
		LongCase(140, 71, 5),
		LongCase(51, 197, 26),
		Exact(LowCase(142, 142, 7)),
		RandomCase(1, 1, 1),
		RandomCase(3000, 3000, 2),
		LowCase(2277,  3000, 26),
		LongCase(2999, 2512, 26),
		LongCase(2741, 3000, 5),
		Exact(LowCase(2977, 3000, 7)),
		RandomCase(100, 100, 1),
	Next(4) //3 [40]
		RandomCase(100000, 100000, 2),
		LowCase(99877, 120211, 26),
		LongCase(100000, 100000, 26),
		LongCase(50401, 125000, 7),
		Exact(LowCase(99877, 120211, 26)),
		RandomCase(100, 100, 2),
		LowCase(97, 111, 26),
		LongCase(140, 71, 5),
		LongCase(51, 197, 26),
		Exact(LowCase(142, 142, 7)),
		RandomCase(1, 1, 1),
		RandomCase(10000, 10000, 2),
		LowCase(9977,  12002, 26),
		LongCase(9999, 8512, 26),
		LongCase(6741, 20000, 5),
		Exact(LowCase(9977, 12002, 7)),
		RandomCase(100, 100, 1),
    Next(9)
		RandomCase(400000, 400000, 2),
		LowCase(399877, 420211, 26),
		LongCase(400000, 400000, 26),
		LongCase(350401, 425000, 7),
		Exact(LowCase(399877, 420211, 7), 17),
		RandomCase(100, 100, 2),
		LongCase(100, 100, 2),
		LowCase(10000, 10000, 2),
		LongCase(10000, 10000, 2),
		RandomCase(100000, 100000, 2),
		LongCase(100000, 100000, 2),
		LowCase(400000, 400000, 2),
		LongCase(400000, 400000, 2),
		RandomCase(1000000, 1000000, 2),
		LongCase(1000000, 1000000, 2),
		RandomCase(1000000, 1000000, 1),
		Exact(LowCase(1000000, 1000000, 2), 56),
		RandomCase(1000000, 1000000, 2),
		LowCase(999877, 1000000, 26),
		LongCase(1000000, 1000000, 26),
		LongCase(950401, 1000000, 7),
		Exact(LowCase(999877, 1000000, 26)),
        LowCase(9977,  12002, 26),
		LongCase(9999, 8512, 26),
		LongCase(6741, 20000, 5),
		Exact(LowCase(9977, 12002, 7)),
	End
#undef Begin
#undef End
#undef Next

}
