#pragma GCC push_options
#pragma GCC diagnostic ignored "-Wall"

#include "testlib.h"

#pragma GCC pop_options

const int N = 1000000;

int main(int argc, char** argv){
	registerValidation();

	inf.readToken("[a-z]{1," + vtos(N) + "}");
	inf.readEoln();
	inf.readToken("[a-z]{1," + vtos(N) + "}");
	inf.readEoln();
	inf.readEof();
	puts("ok");
}
