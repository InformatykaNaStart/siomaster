#include <bits/stdc++.h>
using namespace std;

constexpr auto NAME = "cha";

/*{{{*/
thread_local std::mt19937 gen{std::random_device{}()};

template< typename T >
T rng(T mi, T ma)
{
    return std::uniform_int_distribution< T >{mi, ma}(gen);
}

struct Test
{
    int cnt = 1;

    int a, b;

    virtual void generate() = 0;
    void output(ostream& os)
    {
        generate();
        os << a << ' ' << b << '\n';
        clear(); --cnt;
    }
    virtual void clear() = 0;

    Test& operator*(int v)
    {
        cnt *= v;
        return (*this);
    }
};

struct Groups
{
private:
    static int test_no;
    static char letter;
    static bool beg;
    static bool many_cases;

public:
    template< typename T >
    static void write(const string& name, T&& tes)
    {
        ofstream file(name);
        assert(file.is_open());
        cerr << "Writing " << name << endl;
        tes.output(file);
        file.close();
    }

    static void write_group()
    {
        ++test_no;
        letter = 'a';
        beg = true;
    }

    template< typename T, typename... V >
    static void write_group(T&& a, V&&... var)
    {
        if (beg)
        {
            many_cases = sizeof...(var) or (a.cnt > 1);
            beg = false;
        }

        while (a.cnt)
        {
            write(NAME + to_string(test_no) +
            (many_cases? string(1, letter++) : "")
            + ".in", a);
        }

        write_group(var...);
    }
};

int Groups::test_no = 1;
char Groups::letter = 'a';
bool Groups::beg = true;
bool Groups::many_cases = false;
/*}}}*/

struct SmallTest : Test //b <= 1e6
{
    constexpr static int boundary = (int)1e6;

    void generate()
    {
        a = rng(1, boundary);
        b = rng(1, boundary);
        if (a > b)
            swap(a, b);
    }

    void clear(){}
};

struct ShortSegTest : Test // b - a + 1 <= 1e6
{
    const static int boundary = (int)(1e9);
    const static int maxLength = (int)(1e6);

    void generate()
    {
        a = rng(1, (int)(1e9));
        int dl = rng(1, maxLength);
        b = min((int)(1e9), a + dl);
    }

    void clear(){}
};

struct RandomTest : Test
{
    constexpr static int boundary = (int)(1e9);

    void generate()
    {
        a = rng(1, boundary);
        b = rng(1, boundary);
        if (a > b)
            swap(a, b);
    }

    void clear(){}
};

struct NearlyMaxTest : Test
{
    constexpr static int boundary = (int)(1e9);
    constexpr static int deg = 1000;

    void generate()
    {
        a = rng(1, deg);
        b = rng(boundary - deg + 1, boundary);
    }

    void clear(){}
};

int main()
{
    Groups::write_group(SmallTest() * 5);
    Groups::write_group(ShortSegTest() * 5);
    Groups::write_group(RandomTest() * 5);
    Groups::write_group(RandomTest() * 5, NearlyMaxTest() * 5);
}
